package io.ram.baleen.pipelines;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.ram.baleen.pipelines.entities.Contact;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class ProducerTest {

    private final static String TOPIC = "ram-baleen";
    private final static String BOOTSTRAP_SERVERS = "localhost:9092";

    public static void main(String[] args) throws IOException {

        //String filename = "/Users/rapolu/MyProjects/testbaleen/data/input/100-contacts.csv";
        //String filename = "/Users/rapolu/MyProjects/testbaleen/data/input/java.txt";
        String filename = "/Users/rapolu/MyProjects/testbaleen/data/input/metron.txt";
        publishText(filename);

    }

    private static String readAsString(String fileName) throws IOException {
        List<String> strings = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
        String text = String.join("\n", strings);
        return text;
    }

    private static void publishText(String fileName) throws IOException {

        Producer producer = createProducer();
        try {

            String text = readAsString(fileName);
            ProducerRecord<String, String> rec = new ProducerRecord<>(TOPIC, text);
            producer.send(rec);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } finally {
            producer.close();
        }
    }

    private static List<Contact> readFile(String fileName) {

        List<Contact> contacts = new ArrayList<>();

        try {
            for (String line : Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8)) {
                System.out.println("Line : " + line);
                contacts.add(parseString(line));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Contact: " + contacts);
        return contacts;
    }

    private static void publish(String fileName) {

        List<Contact> contacts = readFile(fileName);
        ObjectMapper objectMapper = new ObjectMapper();
        Producer producer = createProducer();

        try {
            for (Contact contact : contacts) {

                System.out.println(objectMapper.writeValueAsString(contact));
                JsonNode jsonNode = objectMapper.valueToTree(contact);

                ProducerRecord<String, JsonNode> rec = new ProducerRecord<>(TOPIC, jsonNode);
                producer.send(rec);
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } finally {
            producer.close();
        }
    }

    private static Producer<Long, String> createProducer() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "KafkaBaleenProducer");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, LongSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        return new KafkaProducer<>(props);
    }

    private static Contact parseString(String csvStr) {
        StringTokenizer st = new StringTokenizer(csvStr, "|");
        String firstName = st.nextToken();
        String lastName = st.nextToken();
        String companyName = st.nextToken();
        String address = st.nextToken();
        String city = st.nextToken();
        String county = st.nextToken();
        String state = st.nextToken();
        String zip = st.nextToken();
        String phone1 = st.nextToken();
        String phone = st.nextToken();
        String email = st.nextToken();
        String da = st.nextToken();
        return new Contact(firstName, lastName, companyName, address, city, county, state, zip, phone1, phone, email, da);
    }
}
