package io.ram.baleen.pipelines;
import uk.gov.dstl.baleen.core.pipelines.BaleenPipeline;
import uk.gov.dstl.baleen.core.pipelines.PipelineBuilder;
import uk.gov.dstl.baleen.exceptions.BaleenException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FolderPipelineTest {
    public static void main(String[] args) throws IOException, BaleenException {
        String filename = "/Users/rapolu/MyProjects/testbaleen/pipelines/folder-pipeline.yaml";
        //String filename = "/Users/rapolu/MyProjects/testbaleen/pipelines/receiver.yaml";
        String yaml = new String(Files.readAllBytes(Paths.get(filename)));
        //String yaml = new String(Files.readAllBytes(Paths.get(args[0])));

        //PipelineBuilder builder = new PipelineBuilder("My Kafka Pipeline", new YamlPipelineConfiguration(filename));
        PipelineBuilder builder = new PipelineBuilder("Ram2Test Folder Pipeline", yaml);
        BaleenPipeline pipeline = builder.createNewPipeline();


        pipeline.run();
    }
}
